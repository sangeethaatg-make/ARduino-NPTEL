const int ledPin=3;
void setup() {
  // put your setup code here, to run once:
  pinMode(ledPin, OUTPUT);
  Serial.begin(9600);

}

void loop() {
  // put your main code here, to run repeatedly:
int input=analogRead(A0);
int output=map(input,0,1023,0,255);
analogWrite(ledPin,output);
Serial.println(input);
delay(100);
}

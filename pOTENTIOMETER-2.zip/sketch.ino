void setup() {
  // put your setup code here, to run once:
  pinMode(A0, INPUT);
  Serial.begin(9600);
}

void loop() {
  int sensorValue=analogRead(A0);
  Serial.println(sensorValue);
  delay(100);
  // put your main code here, to run repeatedly:

}

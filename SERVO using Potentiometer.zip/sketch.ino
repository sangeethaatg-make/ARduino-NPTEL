 #include <Servo.h>

Servo servo1;

void setup() {
  Serial.begin(9600);
  servo1.attach(9);
}

void loop() {
  int x = analogRead(A0);
  int y = map(x, 0, 1023, 0, 180);

  servo1.write(y);

  Serial.println(y);
  delay(100);
}
const int trigpin = 9;
const int echopin = 10;

const int gl = 2;
const int yl = 3;
const int rl = 4;

const int buzzer = 8;

void setup() {
  pinMode(trigpin, OUTPUT);
  pinMode(echopin, INPUT);

  pinMode(gl, OUTPUT);
  pinMode(yl, OUTPUT);
  pinMode(rl, OUTPUT);

  pinMode(buzzer, OUTPUT);

  Serial.begin(9600);
}

void loop() {

  digitalWrite(trigpin, LOW);
  delayMicroseconds(2);

  digitalWrite(trigpin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigpin, LOW);

  long duration = pulseIn(echopin, HIGH);

  float distance = (duration * 0.0343) / 2;

  Serial.print("Distance: ");
  Serial.print(distance);
  Serial.println(" cm");

  if (distance > 50) {
    digitalWrite(gl, HIGH);
    digitalWrite(yl, LOW);
    digitalWrite(rl, LOW);
    noTone(buzzer);
  }

  else if (distance > 20) {
    digitalWrite(gl, LOW);
    digitalWrite(yl, HIGH);
    digitalWrite(rl, LOW);
    noTone(buzzer);
  }

  else {
    digitalWrite(gl, LOW);
    digitalWrite(yl, LOW);
    digitalWrite(rl, HIGH);
    tone(buzzer, 1000);
  }

  delay(500);
}
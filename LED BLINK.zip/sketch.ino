void setup(){
pinMode(13, OUTPUT);
Serial.begin(9600);
}
void loop(){
  digitalWrite(13, HIGH);
  Serial.println("LED IS ON");
  delay(9600);
  digitalWrite(13,LOW);
  Serial.println("LED IS OFF");
  delay(1000);
}